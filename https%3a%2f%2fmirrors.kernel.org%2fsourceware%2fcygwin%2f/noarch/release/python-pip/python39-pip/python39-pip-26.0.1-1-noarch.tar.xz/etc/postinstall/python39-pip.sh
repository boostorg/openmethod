# Install this package as a pip3 alternative.
PIP3_VERSION=3.9
PIP3_PRIORITY=39
/usr/sbin/alternatives --install /usr/bin/pip3 pip3  /usr/bin/pip3.9 39

